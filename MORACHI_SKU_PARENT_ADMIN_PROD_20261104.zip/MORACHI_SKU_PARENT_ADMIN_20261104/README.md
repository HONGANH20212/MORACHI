# MORACHI – SKU cha cố định / SKU con tự động (Admin Only)

## Nguồn và phạm vi

Bản vá đối chiếu theo code người dùng gửi 04/11/2026: `api/function_app.py`, `api/morachi_sku_core.py`, `admin/admin.js`, `admin/index.html`, `admin/sku-mobile.html`.

**Thay đúng 6 file source:**
1. `api/function_app.py` – thay riêng logic ghi **sản phẩm POST/PUT**, không sửa endpoint đơn hàng, `/api/track`, thanh toán.
2. `api/morachi_sku_core.py` – bộ đếm hiện xét cả SKU cha, tránh trùng SKU biến thể.
3. `api/morachi_parent_sku.py` – file mới cấp SKU cha, SKU con và giữ nguyên mã cũ.
4. `admin/admin.js` – hiện SKU cha, SKU biến thể (chỉ đọc), giữ SKU trong form chỉnh sửa.
5. `admin/index.html` – hiển thị SKU cha trên form sản phẩm.
6. `admin/sku-mobile.html` – hiển thị và tìm kiếm theo SKU cha và SKU biến thể.

**Không sửa** `cart.js`, `index.html` trang chủ, `product-detail.html`, `tracking.html`, `finance_api.py`, `finance_logic.py`, endpoint tạo/hủy/sửa đơn, giá bán hoặc tồn kho.

## Định dạng

- Mã cha: `SKU-MOR-xxxx`, ổn định khi sửa sản phẩm, không cho Admin nhập lại.
- Mã con mới: `SKU-MOR-xxxx-V01`, `SKU-MOR-xxxx-V02`, ...
- `variants[].sku` đã có trước đó **được giữ nguyên**, dù không theo định dạng con mới. `variants[].parent_sku` mới ghi nhận quan hệ cha-con.
- `sku_child_sequence` không giảm khi xóa biến thể, tránh tái sử dụng mã con đã xóa.
- Mã cha được cấp từ bộ đếm SKU-MOR hiện có (nên không nhất thiết bắt đầu từ `0001`), tránh đụng các SKU cũ.

## Thử LOCAL/UAT trước

### 1. Cài source (chưa ghi Cosmos DB)

```bash
cd ~/MORACHI_SHOP
source api/.venv/bin/activate
python3 /duong-dan-giai-nen/MORACHI_SKU_PARENT_ADMIN_20261104/install.py ~/MORACHI_SHOP --check
python3 /duong-dan-giai-nen/MORACHI_SKU_PARENT_ADMIN_20261104/install.py ~/MORACHI_SHOP --apply
python3 -m py_compile api/function_app.py api/morachi_sku_core.py api/morachi_parent_sku.py
node --check admin/admin.js
git diff --check
git status --short
```

Installer **fail closed** nếu điểm tích hợp khác code nguồn đã cung cấp. Backup source được tạo cạnh thư mục dự án `~/MORACHI_PARENT_SKU_BACKUP_...`.

### 2. Kiểm tra sản phẩm cũ trên UAT (read-only)

```bash
python3 /duong-dan-giai-nen/MORACHI_SKU_PARENT_ADMIN_20261104/backfill_parent_skus.py \
    --account mrc-uat --root ~/MORACHI_SHOP --check
```

Nhập Cosmos Key của **mrc-uat** tại prompt kín. Không gửi Key vào chat.

### 3. Backfill trên UAT (CÓ GHI DB, cần kiểm thử/backup)

```bash
python3 /duong-dan-giai-nen/MORACHI_SKU_PARENT_ADMIN_20261104/backfill_parent_skus.py \
    --account mrc-uat --root ~/MORACHI_SHOP --apply
```

Script sao lưu toàn bộ tài liệu sản phẩm vào `~/MORACHI_SKU_BACKUPS/...` (chmod 600) trước khi đòi xác nhận. **Chỉ cập nhật document sản phẩm** (không có `type`), đặt SKU cha mới cho sản phẩm chưa có, SKU con mới cho biến thể chưa có, giữ nguyên SKU/cost/stock/price. Thay đổi từng document bằng ETag; không có giao dịch atomic toàn hệ thống. Nếu bị ngắt giữa chừng, đối chiếu backup và chạy `--check` trước khi tiếp tục.

### 4. Sau khi UAT đạt, mới đưa Production

- Không dùng `git add .`; dùng một worktree riêng dựa trên đúng Production `main`, đối chiếu từng file trước commit.
- Kiểm tra Azure Functions host có thể truy cập trực tiếp hay không; `AuthLevel.ANONYMOUS` + header `x-ms-client-principal` **không** đủ để bảo vệ API khi Function App cho truy cập trực tiếp. Việc bảo vệ này phải được xác nhận trước khi deploy lên Production.
- Chỉ sau khi code Production đã deploy đúng và QA đạt mới chạy backfill Production với `--account morachidb` và `--check`, sau đó quyết định `--apply` có xác nhận/backup.
- **Không dùng khóa Production trên máy Local** trong quá trình test UAT; production backfill chỉ nên chạy tại môi trường vận hành đáng tin cậy.

## Kiểm tra hoạt động

1. Thêm 1 sản phẩm test 2 màu trên UAT: xuất hiện SKU cha và 2 SKU con, không cần nhập SKU bằng tay.
2. Sửa tên/giá sản phẩm: SKU cha và SKU con giữ nguyên.
3. Sửa tên một màu: SKU con, giá JPY, giá vốn, tồn kho vẫn giữ nguyên.
4. Thêm màu mới: có `-V03` hoặc số tiếp theo.
5. Xóa một màu, thêm màu khác: số SKU con **không được tái sử dụng**.
6. Dùng giao diện giỏ hàng/checkout UAT kiểm tra tạo đơn như trước. Không chạy bài kiểm thử tạo đơn trên Production trừ khi có kế hoạch xử lý dữ liệu test.
7. Khôi phục source bằng backup installer nếu cần; **rollback source không tự hoàn tác DB**.

## Giới hạn

- Các SKU cũ là mã legacy, không đổi sang `-VXX` để tránh mất định danh lịch sử.
- Các sản phẩm sửa đồng thời hoặc đổi `brand` hiện chịu giới hạn xử lý partition key cũ trong `function_app.py`. Bản vá không can thiệp vào cơ chế đổi brand này; tránh sửa `brand` trong lúc migration.
- Không triển khai API public backfill; script chạy thủ công với thông tin xác thực trực tiếp trên môi trường tin cậy.
- Installer chỉ nhận chính xác các marker trong source đã cung cấp; nếu báo `STOP` hãy so sánh thay đổi, không ép ghi đè.


## Sửa bổ sung trước khi triển khai Production (04/11)

API public `/api/products` có danh sách field cho phép và ban đầu **không trả SKU cha**.
Gói Production này chỉ thêm `sku` của product vào `PUBLIC_FIELDS` để `admin/sku-mobile.html` hiển thị/tìm kiếm theo SKU cha.
Không công khai `purchase_price_jpy`, `cost_vnd`, hoặc Cosmos metadata.

Trước khi push lên Production, phải xác thực biến môi trường `COSMOS_ALLOWED_ACCOUNT=morachidb` tại backend thực sự phục vụ site.
Kiểm tra Source GitHub Actions đang được deploy tới đúng API (Static Web Apps managed API hay linked Functions).
Nếu installer --check fail, không ép ghi đè.
Backfill phải chạy chế độ --check và có bản sao lưu đầy đủ trước khi chạy --apply.
Việc backfill ảnh hưởng dữ liệu Production, không tự rollback khi revert Git.
