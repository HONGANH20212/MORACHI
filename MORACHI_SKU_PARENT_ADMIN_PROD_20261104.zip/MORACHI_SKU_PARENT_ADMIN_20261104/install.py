#!/usr/bin/env python3
"""MORACHI parent SKU patch. Changes only Admin product UI and Admin product writes.

Usage: python3 install.py ~/MORACHI_SHOP --check | --apply
No data migration, no production deploy, no writes to Cosmos DB.
"""
import argparse
import datetime
import difflib
import shutil
import sys
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent / 'package'


def replace_once(text, before, after, name):
    if after in text:
        # Already installed, don't duplicate patches.
        return text
    n = text.count(before)
    if n != 1:
        raise ValueError(f'STOP: {name} không khớp mẫu ({n} lần). Source đã thay đổi, cần đối chiếu trước.')
    return text.replace(before, after, 1)


def transform_core(src):
    src = replace_once(src,
        "query='SELECT c.id, c.variants FROM c WHERE NOT IS_DEFINED(c.type) AND IS_DEFINED(c.id)'",
        "query='SELECT c.id, c.sku, c.variants FROM c WHERE NOT IS_DEFINED(c.type) AND IS_DEFINED(c.id)'",
        'core SELECT')
    src = replace_once(src,
        "    for doc in all_product_docs(ct):\n        for v in doc.get('variants') or []:",
        "    for doc in all_product_docs(ct):\n"
        "        parent = str(doc.get('sku') or '').strip().upper()\n"
        "        if parent:\n"
        "            if parent in all_codes:\n"
        "                raise ValueError('SKU cha bị trùng trong DB')\n"
        "            all_codes.add(parent)\n"
        "            match = SKU_PATTERN.fullmatch(parent)\n"
        "            if match:\n"
        "                high = max(high, int(match.group(1)))\n"
        "        for v in doc.get('variants') or []:",
        'core current_skus')
    return src


def transform_backend(src):
    # The mobile SKU screen reads /api/products. Expose public parent sku only;
    # never expose purchase_price_jpy, cost_vnd, or Cosmos metadata.
    src = replace_once(src,
        'PUBLIC_FIELDS = {\n    "id", "title", "brand", "category", "subcategory",',
        'PUBLIC_FIELDS = {\n    "id", "sku", "title", "brand", "category", "subcategory",',
        'backend public parent sku')
    src = replace_once(src,
        'from morachi_sku_core import add_skus_on_create, merge_and_assign_on_update\n',
        'from morachi_sku_core import add_skus_on_create, merge_and_assign_on_update\n'
        'from morachi_parent_sku import prepare_new_product, prepare_existing_product\n',
        'backend import')
    src = replace_once(src,
        "            product['variants'] = add_skus_on_create(container, product.get('variants', []))",
        "            product = prepare_new_product(container, product)",
        'backend create')
    src = replace_once(src,
        "            updated['variants'] = merge_and_assign_on_update(\n"
        "                container, existing, updated.get('variants', []))",
        "            updated = prepare_existing_product(container, existing, updated)",
        'backend update')
    return src


def transform_admin_html(src):
    snippet = '''                <input type="hidden" id="product-id">'''
    replacement = '''                <input type="hidden" id="product-id">
                <!-- MORACHI_PRODUCT_PARENT_SKU_V1: display only, server assigns/preserves -->
                <section id="morachi-parent-sku-box" style="background:#f1f5fa;border:1px solid #dbe3ee;border-radius:12px;padding:12px 14px;margin-bottom:16px">
                    <div style="font-size:12px;font-weight:750;color:#4b5563">SKU sản phẩm (mã cha cố định)</div>
                    <div id="morachi-parent-sku-value" style="font-family:monospace;font-size:17px;font-weight:800;margin-top:5px;overflow-wrap:anywhere">Tự tạo khi lưu</div>
                    <div style="font-size:11px;color:#6b7280;margin-top:5px">SKU không đổi khi sửa tên, giá hoặc thêm biến thể. SKU biến thể mới tự động cấp mã con.</div>
                </section>'''
    return replace_once(src, snippet, replacement, 'admin/index.html')


def transform_admin_js(src):
    src = replace_once(src,
        '''    row.dataset.morachiSku = String(data.sku || '');
    container.appendChild(row);''',
        '''    row.dataset.morachiSku = String(data.sku || '');
    // MORACHI_PRODUCT_PARENT_SKU_V1: SKU chỉ đọc, không tự sửa trên browser.
    const skuBadge = document.createElement('div');
    skuBadge.style.cssText = 'grid-column:1/-1;font-family:monospace;font-size:12px;color:#59677a;background:#f2f5fa;padding:7px 10px;border-radius:8px;';
    skuBadge.textContent = 'SKU biến thể: ' + (data.sku || 'Sẽ tự cấp khi lưu sản phẩm');
    row.appendChild(skuBadge);
    container.appendChild(row);''',
        'admin.js addVariantRow')
    src = replace_once(src,
        '''        if (p) {
            document.getElementById("product-id").value = p.id;''',
        '''        if (p) {
            const skuValue = document.getElementById('morachi-parent-sku-value');
            if (skuValue) skuValue.textContent = p.sku || 'Chưa có SKU – cần chạy backfill trước khi sửa';
            document.getElementById("product-id").value = p.id;''',
        'admin.js editProduct')
    src = replace_once(src,
        '''    if(titleEl) titleEl.innerText = isEdit ? "Cập nhật sản phẩm" : "Thêm sản phẩm mới";''',
        '''    if(titleEl) titleEl.innerText = isEdit ? "Cập nhật sản phẩm" : "Thêm sản phẩm mới";
    if (!isEdit) {
        const skuValue = document.getElementById('morachi-parent-sku-value');
        if (skuValue) skuValue.textContent = 'Tự tạo khi lưu';
    }''',
        'admin.js openModal')
    src = replace_once(src,
        '''                            <div class="variants-list">${variantHtml}</div>''',
        '''                            <div style="font-size:11px;color:#59677a;font-family:monospace;margin:4px 0">SKU cha: ${window.escapeAdminHtml?.(p.sku || 'Chưa có SKU') ?? 'Chưa có SKU'}</div>
                            <div class="variants-list">${variantHtml}</div>''',
        'admin.js renderTable')
    return src


def transform_sku_mobile(src):
    src = replace_once(src,
        '''      id: String(p.id ?? index),
      name: String(p.title || 'Sản phẩm chưa có tên'),''',
        '''      id: String(p.id ?? index),
      parentSku: String(p.sku || ''),
      name: String(p.title || 'Sản phẩm chưa có tên'),''',
        'sku-mobile productToUi')
    src = replace_once(src,
        '''const text = [p.name, p.brand, p.category, ...p.variants.flatMap(v=>[v.name,v.sku])].join(' ')''',
        '''const text = [p.name, p.brand, p.category, p.parentSku, ...p.variants.flatMap(v=>[v.name,v.sku])].join(' ')''',
        'sku-mobile search')
    src = replace_once(src,
        "    $('skuCode').textContent = '🏷 ' + (v.sku || 'Chưa cấu hình SKU');",
        "    $('skuCode').textContent = '🏷 SKU cha: ' + (selected.parentSku || 'Chưa cấp') + ' | SKU con: ' + (v.sku || 'Chưa cấp');",
        'sku-mobile detail')
    return src


TRANSFORMS = {
    'api/morachi_sku_core.py': transform_core,
    'api/function_app.py': transform_backend,
    'admin/index.html': transform_admin_html,
    'admin/admin.js': transform_admin_js,
    'admin/sku-mobile.html': transform_sku_mobile,
}


def main():
    parser = argparse.ArgumentParser(description='MORACHI Admin SKU parent+child update')
    parser.add_argument('root', type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    patch = {}
    try:
        for rel, fn in TRANSFORMS.items():
            p = root / rel
            if not p.is_file():
                raise ValueError(f'STOP: Không có file {p}')
            before = p.read_text(encoding='utf-8')
            after = fn(before)
            if before != after:
                patch[p] = after
            print(('SỬA: ' if before != after else 'ĐÃ CÓ: ') + rel)
        new_rel = 'api/morachi_parent_sku.py'
        new_path = root / new_rel
        expected = (PACKAGE / new_rel).read_text(encoding='utf-8')
        if new_path.exists() and new_path.read_text(encoding='utf-8') != expected:
            raise ValueError('STOP: module morachi_parent_sku.py tồn tại nhưng khác gói cài')
        if not new_path.exists():
            patch[new_path] = expected
            print('TẠO: ' + new_rel)
        if args.check:
            print('CHECK OK: đã so khớp các điểm tích hợp, chưa ghi file hoặc Cosmos DB')
            print('Dự kiến thay đổi:', len(patch), 'file')
            return 0
        if not patch:
            print('Không cần cập nhật thêm.')
            return 0
        backup_dir = root.parent / ('MORACHI_PARENT_SKU_BACKUP_' + datetime.datetime.now().strftime('%Y%m%d%H%M%S'))
        backup_dir.mkdir(parents=True, exist_ok=False)
        for p in patch:
            if p.is_file():
                dst = backup_dir / p.relative_to(root)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst)
        for p, content in patch.items():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding='utf-8')
            print('UPDATED:', p.relative_to(root))
        print('APPLY OK. Backup:', backup_dir)
        print('Chỉ sửa SOURCE LOCAL. Chưa ghi DB và chưa deploy. Dùng script backfill riêng sau UAT.')
        return 0
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
