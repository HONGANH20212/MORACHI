#!/usr/bin/env python3
"""One-time, reviewable backfill of permanent parent/child SKUs for MORACHI products.

Run in UAT first. Requires account name and a key typed into a hidden prompt.
Only product docs (type undefined, title+brand defined) are touched; orders are untouched.
"""
import argparse
import datetime
import getpass
import json
import os
import re
import stat
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description='MORACHI SKU parent migration (one-time)')
    parser.add_argument('--account', required=True, help='Cosmos account: mrc-uat or morachidb')
    parser.add_argument('--root', default=str(Path.home() / 'MORACHI_SHOP'), help='Project root')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true', help='Read-only preview')
    group.add_argument('--apply', action='store_true', help='Requires backup and typing confirmation')
    args = parser.parse_args()
    account = args.account.strip().lower()
    if not re.fullmatch(r'[a-z0-9-]{3,44}', account):
        raise SystemExit('STOP: Account không hợp lệ')
    api = Path(args.root).expanduser().resolve() / 'api'
    if not (api / 'morachi_parent_sku.py').is_file():
        raise SystemExit('STOP: Hãy cài bản cập nhật source trước')
    sys.path.insert(0, str(api))
    try:
        from azure.cosmos import CosmosClient
        from azure.core import MatchConditions
        from morachi_sku_core import current_skus
        from morachi_parent_sku import backfill_product
    except ImportError:
        raise SystemExit('STOP: Activate api/.venv with azure-cosmos installed')
    print('MORACHI / SKU cha cố định + SKU biến thể')
    print('Target:', account, '/ morachi-db / products')
    print('Mode:', 'BACKFILL APPLY' if args.apply else 'READ-ONLY CHECK')
    key = getpass.getpass('Cosmos Primary Key (không hiển thị): ')
    if not key:
        raise SystemExit('STOP: Thiếu Key')
    os.environ.update({
        'COSMOS_URL': f'https://{account}.documents.azure.com:443/',
        'COSMOS_KEY': key,
        'COSMOS_DB_NAME': 'morachi-db',
        'COSMOS_CONTAINER_NAME': 'products',
        'COSMOS_ALLOWED_ACCOUNT': account,
    })
    ct = CosmosClient(os.environ['COSMOS_URL'], credential=key) \
        .get_database_client('morachi-db').get_container_client('products')
    del key
    if (ct.read().get('partitionKey', {}).get('paths') or []) != ['/brand']:
        raise SystemExit('STOP: Partition key không phải /brand')
    sql = ("SELECT * FROM c WHERE NOT IS_DEFINED(c.type) AND "
           "IS_DEFINED(c.id) AND IS_DEFINED(c.title) AND IS_DEFINED(c.brand)")
    docs = list(ct.query_items(query=sql, enable_cross_partition_query=True))
    docs.sort(key=lambda d: str(d['id']))
    parents_missing = sum(not str(p.get('sku') or '').strip() for p in docs)
    child_missing = sum(
        not str(v.get('sku') or '').strip()
        for p in docs for v in (p.get('variants') or []) if isinstance(v, dict)
    )
    invalid = [str(p.get('id')) for p in docs if
               not isinstance(p.get('variants') or [], list) or
               not str(p.get('brand') or '').strip() or
               not p.get('_etag') or
               any(not isinstance(v, dict) for v in (p.get('variants') or []))]
    if invalid:
        raise SystemExit('STOP: Có sản phẩm không đủ điều kiện: ' + ', '.join(invalid[:5]))
    used, high = current_skus(ct)  # also rejects any duplicates globally
    print('Products:', len(docs))
    print('Thiếu SKU cha:', parents_missing)
    print('Biến thể thiếu SKU:', child_missing)
    print('SKU hiện có:', len(used))
    print('Bộ đếm legacy cao nhất:', high)
    if args.check:
        print('DRY RUN OK — CHƯA GHI COSMOS DB')
        return
    if not docs:
        raise SystemExit('STOP: Không có sản phẩm phù hợp')
    backup = (Path.home() / 'MORACHI_SKU_BACKUPS' /
              ('parent_sku_' + account + '_' + datetime.datetime.now(
                  datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')))
    backup.mkdir(parents=True, exist_ok=False)
    os.chmod(backup, 0o700)
    backup_file = backup / 'products_before.json'
    fd = os.open(backup_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)
    print('Đã backup toàn bộ product docs:', backup_file)
    print('CHỈ ghi các trường SKU sản phẩm và biến thể; KHÔNG ghi đơn hàng.')
    required = f'BACKFILL {account}'
    if input(f'Nhập chính xác [{required}] để tiếp tục: ').strip() != required:
        raise SystemExit('Đã hủy; chưa ghi DB')
    changed = 0
    try:
        for doc in docs:
            result = backfill_product(ct, doc)
            if all(result.get(k) == doc.get(k) for k in ('sku', 'sku_child_sequence', 'variants')):
                continue
            clean = {k: v for k, v in result.items()
                     if k not in {'_rid', '_self', '_etag', '_attachments', '_ts'}}
            ct.replace_item(
                item=doc['id'], body=clean, etag=doc['_etag'],
                match_condition=MatchConditions.IfNotModified,
            )
            changed += 1
            print('UPDATED', changed, ':', doc['id'])
    except Exception as ex:
        print('STOP: Có lỗi/xung đột sau khi cập nhật', changed, 'sản phẩm.', file=sys.stderr)
        print('Đối chiếu backup:', backup, file=sys.stderr)
        print('Chi tiết lỗi (không gồm credentials):', type(ex).__name__, file=sys.stderr)
        raise SystemExit(2)
    print('DONE: cập nhật', changed, 'sản phẩm. Backup:', backup)
    print('Kiểm tra trên Data Explorer và Admin; không xóa backup.')


if __name__ == '__main__':
    main()
