# MORACHI Auto SKU Production — tương thích code rollback c6f541b/c09a66b

Bản vá chỉ cập nhật 6 file:
- `api/function_app.py`: import SKU handler, cấp SKU trong POST/PUT sản phẩm, trả SKU cha công khai (chỉ mã, không trả giá vốn)
- `api/morachi_sku_core.py`: cấp số SKU-MOR-xxxx toàn hệ thống
- `api/morachi_parent_sku.py`: SKU cha cố định, biến thể mới cấp -Vxx, giữ SKU/giá vốn/tồn kho cũ
- `admin/admin.js`: dữ liệu SKU biến thể không mất khi sửa tên; hiển thị SKU
- `admin/index.html`: hiển thị SKU cha trong form
- `admin/sku-mobile.html`: tra cứu SKU cha

**Không sửa checkout, cart, orders, tracking, webhook, cấu hình SWA hoặc frontend khách.**

Bộ cài từ chối bản code khác baseline `c09a66b`, worktree bẩn, marker code không khớp hoặc thiếu quy tắc Admin trong staticwebapp.config.json.

`--check` chỉ kiểm tra. `--apply` có backup code và chỉ thay đổi 6 file LOCAL. Không kết nối Azure/Cosmos DB.

## Gợi ý

Chạy trên worktree Production đã tạo:

```bash
python3 /path/to/install.py ~/MORACHI_SKU_PROD_20261104171054 --check
```

Sau khi `CHECK OK`, có thể chạy `--apply` và test offline. Không push trước khi kiểm thử đầy đủ và xác nhận Azure Functions backend thực tế; sau đó mới cân nhắc backfill data.

**Cảnh báo:** Backend cũ có endpoint Function `ANONYMOUS`; SWA role chỉ bảo vệ qua SWA reverse proxy. Nếu Function App có direct public hostname, người ngoài có thể bỏ qua SWA role. Phải khóa direct backend hoặc áp dụng auth phía server tin cậy trước khi deploy.

`backfill_parent_skus.py` là công cụ migration dữ liệu thật, không chạy `--apply` trước khi triển khai backend tương thích và backup độc lập DB.
