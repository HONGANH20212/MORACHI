"""Permanent product SKU and child variant codes. NO order/checkout code.

Root SKU is stable (SKU-MOR-nnnn). New children get -V01, -V02 ...
Existing legacy variant SKUs are never replaced; parent_sku links them to root.
"""
import re

from morachi_sku_core import (
    PROTECTED_FIELDS, current_skus, ensure_counter, require_account, reserve_code,
)

CHILD_SEQUENCE_FIELD = 'sku_child_sequence'
CHILD_PREFIX = '-V'
PRIVATE_VARIANT_FIELDS = frozenset(PROTECTED_FIELDS) | {'parent_sku'}


def _norm(value):
    return str(value or '').strip().casefold()


def _sequence_from_existing(parent, variants, stored):
    try:
        high = max(0, int(stored or 0))
    except (ValueError, TypeError):
        high = 0
    prefix = re.escape(parent) + r'-V(\d+)$'
    for variant in variants:
        if isinstance(variant, dict):
            match = re.fullmatch(prefix, str(variant.get('sku') or ''), re.I)
            if match:
                high = max(high, int(match.group(1)))
    return high


def _next_child(parent, sequence, used):
    for _ in range(100000):
        sequence += 1
        code = f'{parent}-V{sequence:02d}'
        if code.upper() not in used:
            used.add(code.upper())
            return code, sequence
    raise RuntimeError('Không cấp được SKU con duy nhất')


def _new_parent(ct):
    used, high = current_skus(ct)
    ensure_counter(ct, high)
    return reserve_code(ct, used), used


def prepare_new_product(ct, product):
    """Call ONLY after Admin product POST is authorized upstream."""
    require_account()
    raw = product.get('variants') or []
    if not isinstance(raw, list):
        raise ValueError('Danh sách biến thể không hợp lệ')
    parent, used = _new_parent(ct)
    next_num = 0
    updated = []
    for item in raw:
        if not isinstance(item, dict) or not _norm(item.get('name')):
            raise ValueError('Biến thể phải có tên hợp lệ')
        code, next_num = _next_child(parent, next_num, used)
        variant = {k: v for k, v in item.items() if k not in PRIVATE_VARIANT_FIELDS}
        variant.update({'sku': code, 'parent_sku': parent})
        updated.append(variant)
    product['sku'] = parent
    product[CHILD_SEQUENCE_FIELD] = next_num
    product['variants'] = updated
    return product


def prepare_existing_product(ct, existing, updated):
    """Preserve product/variant identity, historical prices and metadata."""
    require_account()
    raw = updated.get('variants') or []
    if not isinstance(raw, list):
        raise ValueError('Danh sách biến thể không hợp lệ')
    previous = existing.get('variants') or []
    if not isinstance(previous, list):
        previous = []
    parent = str(existing.get('sku') or '').strip()
    if parent:
        used = None
    else:
        parent, used = _new_parent(ct)
    previous_by_sku = {}
    for index, v in enumerate(previous):
        if isinstance(v, dict) and v.get('sku'):
            key = str(v['sku']).strip().upper()
            if key in previous_by_sku:
                raise ValueError('Sản phẩm có SKU biến thể trùng nhau')
            previous_by_sku[key] = (index, v)
    seen = set()
    merged = []
    next_num = _sequence_from_existing(parent, previous, existing.get(CHILD_SEQUENCE_FIELD))
    for proposed in raw:
        if not isinstance(proposed, dict) or not _norm(proposed.get('name')):
            raise ValueError('Biến thể phải có tên hợp lệ')
        sent_sku = str(proposed.get('sku') or '').strip().upper()
        chosen = None
        if sent_sku:
            chosen = previous_by_sku.get(sent_sku)
            if chosen is None:
                raise ValueError('SKU biến thể không thuộc sản phẩm này; vui lòng tải lại')
            if chosen[0] in seen:
                raise ValueError('SKU biến thể bị lặp trong biểu mẫu')
        else:
            candidates = [
                (i, v) for i, v in enumerate(previous)
                if isinstance(v, dict) and i not in seen
                and _norm(v.get('name')) == _norm(proposed.get('name'))
            ]
            if len(candidates) > 1:
                raise ValueError('Tên biến thể bị trùng, không thể xác định SKU cũ')
            if candidates:
                chosen = candidates[0]
        if chosen:
            idx, original = chosen
            seen.add(idx)
            item = dict(original)
            item.update({k: v for k, v in proposed.items()
                         if k not in PRIVATE_VARIANT_FIELDS})
            item['sku'] = str(original.get('sku') or '').strip()
        else:
            item = {k: v for k, v in proposed.items() if k not in PRIVATE_VARIANT_FIELDS}
            item['sku'] = ''
        item['parent_sku'] = parent
        merged.append(item)
    if any(not x.get('sku') for x in merged):
        if used is None:
            used, _ = current_skus(ct)
        for item in merged:
            if not item['sku']:
                item['sku'], next_num = _next_child(parent, next_num, used)
    codes = [v['sku'].upper() for v in merged]
    if len(codes) != len(set(codes)) or parent.upper() in codes:
        raise ValueError('SKU trùng trong sản phẩm')
    updated['sku'] = parent  # NEVER take client-supplied parent SKU
    updated[CHILD_SEQUENCE_FIELD] = next_num
    updated['variants'] = merged
    return updated


def backfill_product(ct, doc):
    """One-time migration: fill ONLY missing root/child SKUs and relationships.

    The caller must have verified a backup and should save with ETag CAS.
    """
    require_account()
    raw = doc.get('variants') or []
    if not isinstance(raw, list):
        raise ValueError('Danh sách variants không hợp lệ')
    new_doc = dict(doc)
    parent = str(doc.get('sku') or '').strip()
    used = None
    if not parent:
        parent, used = _new_parent(ct)
        new_doc['sku'] = parent
    seq = _sequence_from_existing(parent, raw, doc.get(CHILD_SEQUENCE_FIELD))
    for variant in raw:
        if not isinstance(variant, dict):
            raise ValueError('Dữ liệu variants chứa phần tử không hợp lệ')
    new_vars = [dict(x) for x in raw]
    if any(not str(v.get('sku') or '').strip() for v in new_vars):
        if used is None:
            used, _ = current_skus(ct)
        for variant in new_vars:
            if not str(variant.get('sku') or '').strip():
                variant['sku'], seq = _next_child(parent, seq, used)
    for variant in new_vars:
        variant['parent_sku'] = parent
    new_doc['variants'] = new_vars
    new_doc[CHILD_SEQUENCE_FIELD] = seq
    return new_doc
