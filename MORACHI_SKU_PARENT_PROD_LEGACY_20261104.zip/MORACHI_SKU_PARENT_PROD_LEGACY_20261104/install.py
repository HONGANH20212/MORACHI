#!/usr/bin/env python3
"""Safe compatibility patch for MORACHI production rollback c6f541b/c09a66b.
Only changes product management and admin UI. Does not access DB or network.
"""
from pathlib import Path
import argparse
import ast
import datetime
import json
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE_SHA = 'c09a66b'


def replace_once(text, old, new, label):
    if old not in text:
        raise ValueError(f'STOP {label}: cấu trúc source không khớp bản rollback; KHÔNG ép chạy')
    count = text.count(old)
    if count != 1:
        raise ValueError(f'STOP {label}: điểm tích hợp xuất hiện {count} lần')
    return text.replace(old, new, 1)


def update_backend(src):
    if 'from morachi_parent_sku import' in src or 'from morachi_sku_core import' in src:
        raise ValueError('STOP backend: đã có code Auto SKU khác; cần review trước')
    src = replace_once(src,
        'app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)\n',
        'app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)\n'
        'from morachi_parent_sku import prepare_new_product, prepare_existing_product\n',
        'backend:import')
    src = replace_once(src,
        '    "created_at", "updated_at"\n}\nPUBLIC_VARIANT_FIELDS',
        '    "created_at", "updated_at", "sku"\n}\nPUBLIC_VARIANT_FIELDS',
        'backend:public root SKU only')
    src = replace_once(src,
        '            product = normalize_product(body)\n            now = datetime.utcnow().isoformat() + "Z"',
        '            product = normalize_product(body)\n'
        '            # MORACHI_ADMIN_PARENT_SKU_V1 - product management ONLY\n'
        '            product = prepare_new_product(container, product)\n'
        '            now = datetime.utcnow().isoformat() + "Z"',
        'backend:POST product')
    src = replace_once(src,
        '            updated = normalize_product(body, existing)\n            updated["id"] = p_id',
        '            updated = normalize_product(body, existing)\n'
        '            # MORACHI_ADMIN_PARENT_SKU_V1 - preserve identity/cost/stock of variants\n'
        '            updated = prepare_existing_product(container, existing, updated)\n'
        '            updated["id"] = p_id',
        'backend:PUT product')
    # Do not alter order/checkout routines or storage writes beyond the SKU insertion.
    ast.parse(src)
    return src


def update_admin(src):
    if 'MORACHI_ADMIN_PARENT_SKU_V1' in src:
        raise ValueError('STOP admin: parent SKU đã tồn tại')
    src = replace_once(src,
        '    container.appendChild(row);\n}\n\nwindow.editProduct =',
        '''    // MORACHI_ADMIN_PARENT_SKU_V1: variant identity must survive renaming.
    row.dataset.morachiSku = String(data.sku || '');
    const skuBadge = document.createElement('div');
    skuBadge.style.cssText = 'grid-column:1/-1;font-family:monospace;font-size:12px;color:#57667b;background:#f2f5fa;padding:7px 9px;border-radius:8px;';
    skuBadge.textContent = 'SKU biến thể: ' + (data.sku || 'Tự cấp sau khi lưu');
    row.appendChild(skuBadge);
    container.appendChild(row);
}

window.editProduct =''',
        'admin:variant badge and identity')
    src = replace_once(src,
        '            document.getElementById("product-id").value = p.id;',
        '''                const parentLabel = document.getElementById('morachi-parent-sku-value');
                if (parentLabel) parentLabel.textContent = p.sku || 'Chưa có SKU cha – cần backfill';
            document.getElementById("product-id").value = p.id;''',
        'admin:edit product parent display')
    src = replace_once(src,
        '    if(titleEl) titleEl.innerText = isEdit ? "Cập nhật sản phẩm" : "Thêm sản phẩm mới";',
        '''    if(titleEl) titleEl.innerText = isEdit ? "Cập nhật sản phẩm" : "Thêm sản phẩm mới";
    if (!isEdit) {
        const parentLabel = document.getElementById('morachi-parent-sku-value');
        if (parentLabel) parentLabel.textContent = 'Tự cấp sau khi lưu';
    }''',
        'admin:new product parent display')
    src = replace_once(src,
        '                    image: vImageUrl\n                });',
        '''                    image: vImageUrl,
                    sku: row.dataset.morachiSku || ''
                });''',
        'admin:send SKU with edit')
    src = replace_once(src,
        '                            <div class="variants-list">${variantHtml}</div>',
        '''                            <div class="morachi-root-sku" style="font-size:11px;color:#59677a;font-family:monospace;margin:4px 0">SKU cha: ${String(p.sku || 'Chưa có SKU').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}</div>
                            <div class="variants-list">${variantHtml}</div>''',
        'admin:catalog parent display')
    return src


def update_admin_html(src):
    return replace_once(src,
        '                <input type="hidden" id="product-id">',
        '''                <input type="hidden" id="product-id">
                <!-- MORACHI_ADMIN_PARENT_SKU_V1: server generated; read-only -->
                <section id="morachi-parent-sku-box" style="background:#f1f5fa;border:1px solid #dbe3ee;border-radius:12px;padding:12px 14px;margin-bottom:16px">
                    <div style="font-size:12px;font-weight:750;color:#4b5563">SKU cha cố định</div>
                    <div id="morachi-parent-sku-value" style="font-family:monospace;font-size:17px;font-weight:800;margin-top:5px;overflow-wrap:anywhere">Tự cấp sau khi lưu</div>
                    <div style="font-size:11px;color:#6b7280;margin-top:5px">Giữ nguyên khi đổi tên, giá hoặc thêm phân loại.</div>
                </section>''', 'admin/index:form parent SKU')


def update_sku_mobile(src):
    src = replace_once(src,
        '''      id: String(p.id ?? index),
      name: String(p.title || 'Sản phẩm chưa có tên'),''',
        '''      id: String(p.id ?? index),
      parentSku: String(p.sku || ''),
      name: String(p.title || 'Sản phẩm chưa có tên'),''',
        'sku-mobile:model')
    src = replace_once(src,
        '''const text = [p.name, p.brand, p.category, ...p.variants.flatMap(v=>[v.name,v.sku])].join(' ')''',
        '''const text = [p.name, p.brand, p.category, p.parentSku, ...p.variants.flatMap(v=>[v.name,v.sku])].join(' ')''',
        'sku-mobile:search')
    src = replace_once(src,
        "    $('skuCode').textContent = '🏷 ' + (v.sku || 'Chưa cấu hình SKU');",
        "    $('skuCode').textContent = '🏷 Cha: ' + (selected.parentSku || 'Chưa cấp') + ' | Biến thể: ' + (v.sku || 'Chưa cấp');",
        'sku-mobile:details')
    return src


TRANSFORMS = {
    'api/function_app.py': update_backend,
    'admin/admin.js': update_admin,
    'admin/index.html': update_admin_html,
    'admin/sku-mobile.html': update_sku_mobile,
}
NEW = ['api/morachi_sku_core.py', 'api/morachi_parent_sku.py']


def git(root, *cmd):
    return subprocess.check_output(['git', '-C', str(root), *cmd], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description='Compatible Admin parent SKU patch for prod rollback')
    parser.add_argument('root', type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    try:
        rev = git(root, 'rev-parse', '--short=7', 'HEAD')
        if rev != BASE_SHA:
            raise ValueError(f'STOP: HEAD={rev} (cần {BASE_SHA}); chỉ dùng với worktree rollback hiện tại')
        status = git(root, 'status', '--porcelain')
        if status:
            raise ValueError('STOP: worktree có thay đổi, vui lòng dùng worktree sạch')
        cfg = root / 'staticwebapp.config.json'
        if not cfg.exists():
            raise ValueError('STOP: không có staticwebapp.config.json để kiểm tra phân quyền')
        routes = json.loads(cfg.read_text(encoding='utf-8'))['routes']
        def has_admin_rule(route, method):
            return any((r.get('route') == route and method in r.get('methods',[]) and
                        'morachiadmin' in r.get('allowedRoles',[])) for r in routes)
        for route, method in [('/api/products', 'POST'), ('/api/products/*','PUT')]:
            if not has_admin_rule(route, method):
                raise ValueError(f'STOP: thiếu SWA role morachiadmin cho {method} {route}')
        if not any(r.get('route') == '/admin*' and 'morachiadmin' in r.get('allowedRoles',[]) for r in routes):
            raise ValueError('STOP: thiếu SWA role morachiadmin cho /admin*')
        pending = {}
        for rel, fn in TRANSFORMS.items():
            file = root / rel
            if not file.is_file(): raise ValueError(f'STOP: thiếu {rel}')
            new = fn(file.read_text(encoding='utf-8'))
            pending[file] = new
            print('MODIFY', rel)
        for rel in NEW:
            file = root / rel
            if file.exists(): raise ValueError(f'STOP: file đã tồn tại, không ghi đè: {rel}')
            pending[file] = (HERE / 'package' / rel).read_text(encoding='utf-8')
            ast.parse(pending[file])
            print('CREATE', rel)
        if args.check:
            print('CHECK OK: nguồn phù hợp, đã xác nhận 6 file; CHƯA THAY ĐỔI gì')
            return 0
        stamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        backup = root.parent / ('MORACHI_SKU_PROD_BACKUP_' + stamp)
        backup.mkdir(parents=True, exist_ok=False)
        for file in pending:
            if file.is_file():
                target = backup / file.relative_to(root)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, target)
        for file, content in pending.items():
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(content, encoding='utf-8')
            print('UPDATED', file.relative_to(root))
        print('APPLY OK; backup:', backup)
        print('Chỉ cập nhật SOURCE LOCAL, KHÔNG deploy, KHÔNG ghi Cosmos DB')
        return 0
    except (ValueError, KeyError, subprocess.CalledProcessError, OSError) as exc:
        print('STOP:', exc, file=sys.stderr)
        return 2

if __name__ == '__main__':
    sys.exit(main())
