"""Pure offline tests with a fake Cosmos container; no key/no internet/no writes."""
from pathlib import Path
import copy
import os
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'package' / 'api'))
# Dependency stubs: runtime remains unchanged; required only for isolated tests.
azure = types.ModuleType('azure'); azure.__path__ = []
core = types.ModuleType('azure.core')
class MatchConditions: IfNotModified = 'IfNotModified'
core.MatchConditions = MatchConditions
cosmos = types.ModuleType('azure.cosmos'); cosmos.__path__=[]
exceptions = types.ModuleType('azure.cosmos.exceptions')
class CosmosResourceExistsError(Exception): pass
exceptions.CosmosResourceExistsError = CosmosResourceExistsError
sys.modules.update({'azure':azure, 'azure.core':core, 'azure.cosmos':cosmos,
                    'azure.cosmos.exceptions':exceptions})
import morachi_sku_core as sku_core
import morachi_parent_sku as parent

class NotFound(Exception): status_code=404
class FakeDB:
    def __init__(self, docs, last=None):
        self.docs = copy.deepcopy(docs)
        self.counter = {'id':sku_core.COUNTER_ID,'brand':sku_core.COUNTER_BRAND,'last':last, '_etag':'1'} if last is not None else None
    def query_items(self, query, enable_cross_partition_query=True):
        return [{k:v for k,v in d.items() if k in ('id','sku','variants')} for d in self.docs]
    def read_item(self, item, partition_key):
        if self.counter is None: raise NotFound()
        return dict(self.counter)
    def create_item(self, body):
        if self.counter is not None: raise CosmosResourceExistsError()
        self.counter= dict(body); self.counter['_etag']='1'; return dict(self.counter)
    def patch_item(self, item, partition_key, patch_operations, **kw):
        for op in patch_operations:
            if op['op']=='incr': self.counter['last']+=op['value']
            elif op['op']=='set': self.counter['last']=op['value']
        return dict(self.counter)

os.environ.update({'COSMOS_URL':'https://mrc-uat.documents.azure.com:443/',
                   'COSMOS_ALLOWED_ACCOUNT':'mrc-uat',
                   'COSMOS_DB_NAME':'morachi-db', 'COSMOS_CONTAINER_NAME':'products'})
legacy = [{'id':'one','sku':'', 'variants':[
    {'name':'Màu hồng','sku':'SKU-MOR-0001','purchase_price_jpy':600,'cost_vnd':102000,'stock':4},
    {'name':'Màu đỏ','sku':'SKU-MOR-0002','stock':9}]}]
ct = FakeDB(legacy)
assert sku_core.current_skus(ct)==({'SKU-MOR-0001','SKU-MOR-0002'},2)
# Backfill does not alter historical SKU or sensitive inventory/cost.
updated = parent.backfill_product(ct,dict(legacy[0]))
assert updated['sku']=='SKU-MOR-0003'
assert updated['variants'][0]['sku']=='SKU-MOR-0001'
assert updated['variants'][0]['cost_vnd']==102000
assert updated['variants'][0]['parent_sku']=='SKU-MOR-0003'
assert parent.backfill_product(ct,updated)==updated
ct.docs=[updated]
# Renaming existing variant preserves SKU and price; new child gets parent-V01.
out = parent.prepare_existing_product(ct,updated,{'variants':[
    {'name':'Hồng đổi tên','sku':'SKU-MOR-0001','stock':5},
    {'name':'Màu đỏ','sku':'SKU-MOR-0002','stock':3},
    {'name':'Màu xanh','sku':'' ,'stock':1},
]})
assert out['sku']=='SKU-MOR-0003'
assert out['variants'][0]['sku']=='SKU-MOR-0001'
assert out['variants'][0]['purchase_price_jpy']==600
assert out['variants'][0]['cost_vnd']==102000
assert out['variants'][2]['sku']=='SKU-MOR-0003-V01'
assert out['sku_child_sequence']==1
ct.docs=[out]
# Delete child then add another -> V02 never V01.
out2=parent.prepare_existing_product(ct,out,{'variants':[
    {'name':'Hồng đổi tên','sku':'SKU-MOR-0001','stock':5},
    {'name':'Màu đỏ','sku':'SKU-MOR-0002','stock':3},
    {'name':'Màu tím','sku':''},
]})
assert out2['variants'][2]['sku']=='SKU-MOR-0003-V02'
assert out2['sku_child_sequence']==2
assert out2['sku']=='SKU-MOR-0003'
ct.docs=[out2]
# Brand change doesn't affect SKU; edited name works with SKU identity.
out3=parent.prepare_existing_product(ct,out2,{'brand':'NEWBRAND','variants':[
    {'name':'Hồng','sku':'SKU-MOR-0001'},
    {'name':'Màu đỏ','sku':'SKU-MOR-0002'},
    {'name':'Tím','sku':'SKU-MOR-0003-V02'},
]})
assert out3['sku']==out2['sku']
assert out3['variants'][2]['sku']=='SKU-MOR-0003-V02'
# Fresh product: parent global seq & child per product.
new = parent.prepare_new_product(ct, {'title':'NEW','variants':[{'name':'A','stock':2}, {'name':'B'}]})
assert new['sku']=='SKU-MOR-0004'
assert [v['sku'] for v in new['variants']]==['SKU-MOR-0004-V01','SKU-MOR-0004-V02']
# Invalid manually submitted SKU must not hijack another variant.
try:
    parent.prepare_existing_product(ct,out2,{'variants':[{'name':'X','sku':'SKU-MOR-9999'}]})
except ValueError: pass
else: raise AssertionError('Unrecognized SKU was accepted')
print('PASS: backfill, legacy SKU preservation, permanent parent, rename, new child, no reuse, invalid SKU, no DB')
